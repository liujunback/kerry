@echo off
chcp 65001 >nul

echo ========================================
echo KEC WMS 打印中间件 - 创建分发包
echo ========================================
echo.

set VERSION=1.0.0
set BUILD_DATE=%date:~0,4%-%date:~5,2%-%date:~8,2%
set PACKAGE_NAME=KEC-WMS-PrintAgent-v%VERSION%
set OUTPUT_DIR=..\release

echo [信息] 版本: %VERSION%
echo [信息] 构建日期: %BUILD_DATE%
echo [信息] 包名: %PACKAGE_NAME%
echo.

REM 创建输出目录
if not exist "%OUTPUT_DIR%" (
    mkdir "%OUTPUT_DIR%"
)

REM 创建临时打包目录
set TEMP_DIR=%TEMP%\%PACKAGE_NAME%
if exist "%TEMP_DIR%" (
    rmdir /S /Q "%TEMP_DIR%"
)
mkdir "%TEMP_DIR%"

echo [1/4] 复制文件...

REM 复制主程序
copy /Y "kec-wms-print-agent.exe" "%TEMP_DIR%\" >nul

REM 复制脚本
copy /Y "install.bat" "%TEMP_DIR%\" >nul
copy /Y "uninstall.bat" "%TEMP_DIR%\" >nul
copy /Y "start-background.bat" "%TEMP_DIR%\" >nul
copy /Y "stop-service.bat" "%TEMP_DIR%\" >nul
copy /Y "run-hidden.vbs" "%TEMP_DIR%\" >nul

REM 复制服务脚本
mkdir "%TEMP_DIR%\service"
copy /Y "service\install-service.bat" "%TEMP_DIR%\service\" >nul
copy /Y "service\uninstall-service.bat" "%TEMP_DIR%\service\" >nul

REM 复制文档
copy /Y "用户安装指南.md" "%TEMP_DIR%\" >nul
copy /Y "安装说明.md" "%TEMP_DIR%\" >nul
copy /Y "后台运行指南.md" "%TEMP_DIR%\" >nul
copy /Y "README.txt" "%TEMP_DIR%\" >nul
copy /Y "VERSION.txt" "%TEMP_DIR%\" >nul

echo ✓ 文件复制完成

echo.
echo [2/4] 创建 ZIP 压缩包...

REM 使用 PowerShell 创建 ZIP 文件
powershell -Command "Compress-Archive -Path '%TEMP_DIR%\*' -DestinationPath '%OUTPUT_DIR%\%PACKAGE_NAME%.zip' -Force"

if %ERRORLEVEL% NEQ 0 (
    echo [错误] ZIP 创建失败
    pause
    exit /b 1
)

echo ✓ ZIP 压缩包创建完成

echo.
echo [3/4] 计算文件大小...

for %%A in ("%OUTPUT_DIR%\%PACKAGE_NAME%.zip") do (
    set SIZE=%%~zA
)

REM 转换为 MB
set /a SIZE_MB=%SIZE% / 1048576

echo ✓ 压缩包大小: %SIZE_MB% MB

echo.
echo [4/4] 清理临时文件...

rmdir /S /Q "%TEMP_DIR%"

echo ✓ 清理完成

echo.
echo ========================================
echo ✓ 分发包创建成功！
echo ========================================
echo.
echo 输出文件: %OUTPUT_DIR%\%PACKAGE_NAME%.zip
echo 文件大小: %SIZE_MB% MB
echo.
echo 分发说明:
echo   1. 将 ZIP 文件发送给用户
echo   2. 用户解压后双击 install.bat 安装
echo   3. 或双击 start-background.bat 直接使用
echo.
echo 按任意键打开输出目录...
pause >nul

REM 打开输出目录
explorer "%OUTPUT_DIR%"
