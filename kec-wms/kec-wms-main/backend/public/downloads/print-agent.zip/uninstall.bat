@echo off
chcp 65001 >nul

echo ========================================
echo KEC WMS 打印中间件 - 卸载程序
echo ========================================
echo.

REM 检查安装位置
set "INSTALL_DIR1=%ProgramFiles%\KEC-WMS\PrintAgent"
set "INSTALL_DIR2=%LOCALAPPDATA%\KEC-WMS\PrintAgent"

if exist "%INSTALL_DIR1%" (
    set "INSTALL_DIR=%INSTALL_DIR1%"
) else if exist "%INSTALL_DIR2%" (
    set "INSTALL_DIR=%INSTALL_DIR2%"
) else (
    echo [信息] 未找到安装文件
    pause
    exit /b 0
)

echo [信息] 找到安装目录: %INSTALL_DIR%
echo.

REM 停止运行中的进程
echo [信息] 正在停止运行中的服务...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":12212"') do (
    taskkill /PID %%a /F >nul 2>nul
)

REM 删除安装目录
echo [信息] 正在删除文件...
rmdir /S /Q "%INSTALL_DIR%" 2>nul

REM 删除桌面快捷方式
del "%USERPROFILE%\Desktop\KEC WMS 打印中间件.lnk" 2>nul

echo.
echo [成功] 卸载完成
echo.
pause
