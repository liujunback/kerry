@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo KEC WMS 打印中间件 - 安装程序
echo ========================================
echo.

REM 检查管理员权限
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [警告] 建议以管理员身份运行以安装到 Program Files
    echo.
    set "INSTALL_DIR=%LOCALAPPDATA%\KEC-WMS\PrintAgent"
) else (
    set "INSTALL_DIR=%ProgramFiles%\KEC-WMS\PrintAgent"
)

echo [信息] 安装目录: %INSTALL_DIR%
echo.

REM 创建安装目录
if not exist "%INSTALL_DIR%" (
    mkdir "%INSTALL_DIR%"
)

REM 复制可执行文件
echo [信息] 正在复制文件...
copy /Y "kec-wms-print-agent.exe" "%INSTALL_DIR%\kec-wms-print-agent.exe" >nul
if %ERRORLEVEL% NEQ 0 (
    echo [错误] 文件复制失败
    pause
    exit /b 1
)
copy /Y "SumatraPDF-3.4.6-32.exe" "%INSTALL_DIR%\SumatraPDF-3.4.6-32.exe" >nul
if %ERRORLEVEL% NEQ 0 (
    echo [错误] PDF 打印组件复制失败
    pause
    exit /b 1
)

REM 创建启动脚本
echo @echo off > "%INSTALL_DIR%\启动打印中间件.bat"
echo chcp 65001 ^>nul >> "%INSTALL_DIR%\启动打印中间件.bat"
echo echo 正在启动 KEC WMS 打印中间件... >> "%INSTALL_DIR%\启动打印中间件.bat"
echo echo WebSocket 服务地址: ws://127.0.0.1:12212 >> "%INSTALL_DIR%\启动打印中间件.bat"
echo echo. >> "%INSTALL_DIR%\启动打印中间件.bat"
echo echo 请保持此窗口打开 >> "%INSTALL_DIR%\启动打印中间件.bat"
echo echo 按 Ctrl+C 可停止服务 >> "%INSTALL_DIR%\启动打印中间件.bat"
echo echo. >> "%INSTALL_DIR%\启动打印中间件.bat"
echo "%INSTALL_DIR%\kec-wms-print-agent.exe" >> "%INSTALL_DIR%\启动打印中间件.bat"

REM 创建桌面快捷方式
echo [信息] 创建桌面快捷方式...
set "SHORTCUT=%USERPROFILE%\Desktop\KEC WMS 打印中间件.lnk"
powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut('%SHORTCUT%'); $SC.TargetPath = '%INSTALL_DIR%\启动打印中间件.bat'; $SC.WorkingDirectory = '%INSTALL_DIR%'; $SC.Description = 'KEC WMS 打印中间件'; $SC.Save()"

echo.
echo ========================================
echo [成功] 安装完成！
echo ========================================
echo.
echo 安装位置: %INSTALL_DIR%
echo 桌面快捷方式: %SHORTCUT%
echo.
echo 使用方法:
echo   1. 双击桌面上的"KEC WMS 打印中间件"快捷方式
echo   2. 或运行: %INSTALL_DIR%\启动打印中间件.bat
echo.
pause
