# KEC WMS 打印中间件 - Windows 安装包

## 安装步骤

1. 双击 `install.bat` 运行安装程序
2. 安装完成后，桌面会出现"KEC WMS 打印中间件"快捷方式
3. 双击快捷方式启动中间件服务

## 安装位置

- 管理员权限: `C:\Program Files\KEC-WMS\PrintAgent`
- 普通用户: `%LOCALAPPDATA%\KEC-WMS\PrintAgent`

## 使用说明

1. 启动中间件后，保持窗口打开
2. 前端页面会自动连接到 ws://127.0.0.1:12212
3. 按 Ctrl+C 可停止服务

## 卸载

双击 `uninstall.bat` 运行卸载程序

## 文件说明

- `kec-wms-print-agent.exe` - 打印中间件可执行文件
- `SumatraPDF-3.4.6-32.exe` - PDF 静默打印组件
- `install.bat` - 安装脚本
- `uninstall.bat` - 卸载脚本
- `README.txt` - 本说明文件
