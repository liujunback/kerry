import json
import requests
import time
from TMS.public.Controller_Login import Controller_Login

def inbound(tracking_number):
    token=Controller_Login()
    url = "http://47.107.105.241:22000/controller/inbound/package/hand"

    payload={
            "token":token,
            "height":10,
            "isPrint":0,
            "isVol":1,
            "length":100,
            "trackingNumber":tracking_number,
            "width":300,
            "weight":1200,
    "imgBase64":"",
    "isPreviewInput":0
        }
    headers = {
      'Authorization': token,
      'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
    if json.loads(response.text)["code"] != 200:
        print(response.text)
    print(json.loads(response.text)["msg"])
