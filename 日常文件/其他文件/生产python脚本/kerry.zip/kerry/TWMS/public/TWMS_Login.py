import json
import random
import re

import datetime
import requests




def  Twms_login():
    res1 = requests.get('https://stg.hk.timeswms.com/admin/login')
    c_token=re.findall(r"name=\"_token\" value=\"(.+?)\"", res1.text)[0]
    print(c_token)
    payload={
            "username":"zhu.ting",
            "password":"123456",
            "_token":c_token
        }
    login= requests.post('https://stg.hk.timeswms.com/admin/login',data = payload,cookies = res1.cookies)

    XSRF_TOKEN = re.findall(r"XSRF-TOKEN=(.+?) for stg.hk",str(login.cookies))[0]
    laravel_session = re.findall(r"laravel_session=(.+?) for stg.hk",str(login.cookies))[0]

    headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Cookie': 'XSRF-TOKEN='+XSRF_TOKEN+'; laravel_session=' + laravel_session
    }
    response = requests.request("GET", "https://stg.hk.timeswms.com/admin/dashboard",headers=headers)
    # print(response.text)
    csrf_token = re.findall(r"csrf-token\" content=\"(.+?)\">",str(response.text))[0]
    print(csrf_token)
    if "Logout" in login.text:
        print("登陆成功")
    return {"cookies":{
                            "XSRF-TOKEN":re.findall(r"XSRF-TOKEN=(.+?) for stg.hk",str(login.cookies))[0],
                            "laravel_session":re.findall(r"laravel_session=(.+?) for stg.hk",str(login.cookies))[0]
                        },
            "_token":c_token,
            "csrf_token":csrf_token
    }


print(json.dumps(Twms_login()))