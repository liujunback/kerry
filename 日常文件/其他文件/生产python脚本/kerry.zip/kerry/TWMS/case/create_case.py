




import unittest
from time import sleep

from FOMS.public.Login import Login_Foms
from FOMS.public.create_Order import create_Order
from TWMS.public.TWMS_Close_box import Twms_Close_box
from TWMS.public.TWMS_Handover import Twms_Handover
from TWMS.public.TWMS_Login import Twms_login
from TWMS.public.TWMS_Order_Ids import Twms_Order_Ids
from TWMS.public.TWMS_Order_Wave import Twms_Order_Wave
from TWMS.public.TWMS_pack_by_order import Twms_pack_by_order
from TWMS.public.TWMS_progress_wave import Twms_progress_wave
from TWMS.public.TWMS_wave_pack import Twms_Create_wave


class MyTestCase(unittest.TestCase):



    def test_case_order_create(self):
        for i in range(1):
            Foms_token = Login_Foms()

            sku_code = "TESTTORI20230803003"

            FOMS_order = "backtest20231011012135"
            # sleep(60)
            login_data = Twms_login()

            wave_data = Twms_Create_wave(login_data)

            order_id = Twms_Order_Ids(FOMS_order,login_data)
            sleep(10)
            Twms_Order_Wave(login_data,wave_data,order_id)
            sleep(10)
            Twms_progress_wave(login_data,wave_data)
            sleep(10)
            Twms_pack_by_order(login_data,wave_data)
            sleep(10)
            tracking_number = Twms_Close_box(login_data,FOMS_order)
            sleep(10)
            Twms_Handover(login_data,tracking_number)






if __name__ == '__main__':
    unittest.main()