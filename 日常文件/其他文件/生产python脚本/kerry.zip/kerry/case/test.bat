python test.py
python test.py
pause