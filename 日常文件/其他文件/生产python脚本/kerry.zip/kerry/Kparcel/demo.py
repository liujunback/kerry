import time
from locust import HttpUser, task, between

class QuickstartUser(HttpUser):
    wait_time = between(1, 2)
    host = "https://www.baidu.com/"

@task
def index_page(self):
    self.client.get("/hello")
    self.client.get("/world")