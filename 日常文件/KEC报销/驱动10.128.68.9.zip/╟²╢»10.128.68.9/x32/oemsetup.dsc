;
; Driver Installer Section (For DrvInst)
;
; Copyright (c) 2007-2015 RICOH COMPANY, LTD
; All Rights Reserved
;

[DrvInst]
DrvInst=PCL6 Driver for Universal Print,RICOH PCL6 UniversalDriver V4.8
Comment="PCL6 Driver (For Windows)"
DriverType=PCL6
DriverArchitecture=ARC2010
Version=3
IniFileName=rpdinstv.ini,allusers
IniFileSupport=4
ScenarioInstallOK=ON
RConfigFileOSVersion=3
UserCodeOK=ON
DriverVersion=4.8.0.0
RCFFormatVersion=1.0
PackageType=2
InstallBidi=ON
UserIDSupportLevel=1
